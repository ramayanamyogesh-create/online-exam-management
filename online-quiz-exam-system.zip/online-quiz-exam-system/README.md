# QuizCore — Online Quiz & Examination Management System

A PHP 8 + MySQL starter application with a responsive dark dashboard, administrator and student roles, quiz/question management, timed MCQ and true/false exams, automatic scoring, and result history.

## Features
- Student registration and secure password hashing
- Admin login, overview, student list and quiz management
- Add/edit/delete quizzes and questions
- Publish/unpublish exams
- Timed exam interface with automatic browser-side submission at timer expiry
- Automatic scoring and student result history
- PDO prepared statements, output escaping, session ID regeneration and CSRF tokens
- Responsive dark dashboard UI

## Requirements
- XAMPP with PHP 8.0+ and MySQL/MariaDB
- A modern browser

## XAMPP installation
1. Install and open XAMPP.
2. Start **Apache** and **MySQL**.
3. Extract `online-quiz-exam-system.zip` into `C:\\xampp\\htdocs\\`.
4. Rename the extracted folder to `online-quiz-exam-system` if necessary.
5. Open `http://localhost/phpmyadmin`.
6. Choose **Import**, select `database.sql` from this project, and import it. The script creates `quiz_exam_db`.
7. If your MySQL credentials differ from the XAMPP defaults, edit `config.php` (`DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`).
8. Create an administrator account (one-time):
   - Open phpMyAdmin → select database `quiz_exam_db` → SQL.
   - Run the SQL below after replacing the sample values. Generate a hash in PHP as shown in the next step; never store a plain-text password.
   - Easiest method: create a temporary file `make_admin.php` in the project root with the code below, open it once, then delete it.
9. Visit `http://localhost/online-quiz-exam-system/login.php`.

### One-time administrator creation
Create `make_admin.php` in the project root:

```php
<?php
require_once __DIR__ . '/config.php';
$name = 'System Administrator';
$email = 'admin@example.com';
$password = 'ChangeThisPassword123!';
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = db()->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'admin')");
$stmt->execute([$name,$email,$hash]);
echo "Admin created. Delete this file now.";
```

Open `http://localhost/online-quiz-exam-system/make_admin.php` once, then **delete `make_admin.php` immediately**. Sign in with the email/password set in that file and change the password by updating the account through a future password-management feature or by recreating the hash securely. Do not leave the setup script on a public server.

## First use
1. Sign in as administrator.
2. Open **Manage quizzes** → **New quiz**.
3. Add the quiz title, duration and description. Save.
4. Add questions. MCQ questions need four options; true/false uses the first two choices automatically.
5. Return to the quiz list and publish the quiz.
6. Students register from the login page and can take published exams.
7. Scores are calculated automatically and displayed in My results.

## Important limitations / production hardening
This is a functional local-development starter, not a proctored/high-stakes exam platform. The countdown is browser-side and should be enforced server-side before production. Add server-side deadline validation, one-attempt policies, answer randomization, audit logs, password reset, email verification, admin account management, rate limiting, HTTPS, backups, and a proper password-change screen before deployment. Do not expose a XAMPP development server directly to the public internet.

## Project structure
```
online-quiz-exam-system/
├── admin/              # Administrator pages
├── student/            # Student dashboard, exam and results
├── includes/           # Shared helpers and authorization
├── assets/             # Dark theme CSS and JavaScript
├── config.php          # Database connection
├── database.sql        # Schema
├── login.php
├── register.php
├── logout.php
└── README.md
```
