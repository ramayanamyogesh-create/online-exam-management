<?php
require_once __DIR__.'/../includes/functions.php';require_role('admin');
$users=db()->query("SELECT id,name,email,created_at FROM users WHERE role='student' ORDER BY created_at DESC")->fetchAll();
header_html('Users');?><div class="page-head"><div><h1>Students</h1><p class="sub">Registered student accounts.</p></div></div><div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead><tbody><?php foreach($users as $u):?><tr><td><?=e($u['name'])?></td><td><?=e($u['email'])?></td><td><?=e($u['created_at'])?></td></tr><?php endforeach?><?php if(!$users):?><tr><td colspan="3" class="empty">No students registered.</td></tr><?php endif?></tbody></table></div><?php footer_html();?>
