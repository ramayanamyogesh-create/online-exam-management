document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{
    if(!confirm(el.dataset.confirm||'Are you sure?')) e.preventDefault();
  }));
  const timer=document.querySelector('[data-countdown]');
  if(timer){let seconds=parseInt(timer.dataset.countdown,10);const target=Date.now()+seconds*1000;
    const tick=()=>{let left=Math.max(0,Math.floor((target-Date.now())/1000));timer.textContent=String(Math.floor(left/60)).padStart(2,'0')+':'+String(left%60).padStart(2,'0');
      if(left<=0){const form=document.querySelector('#examForm');if(form)form.submit();}else setTimeout(tick,500);};tick();}
});
