<?php
require_once __DIR__ . '/../config.php';

function e(?string $value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function is_logged_in(): bool { return isset($_SESSION['user']); }
function current_user(): array { return $_SESSION['user'] ?? []; }
function require_login(): void { if (!is_logged_in()) redirect('../login.php'); }
function require_role(string $role): void {
    require_login();
    if ((current_user()['role'] ?? '') !== $role) {
        http_response_code(403); exit('Access denied.');
    }
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['csrf'])) {
        $token = $_POST['csrf'] ?? $_GET['csrf'] ?? '';
        if (!hash_equals($_SESSION['csrf'] ?? '', $token)) {
            http_response_code(419); exit('Invalid security token. Refresh and try again.');
        }
    }
}
function flash(string $message, string $type='success'): void { $_SESSION['flash'] = [$message, $type]; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        [$m,$t] = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert '.e($t).'">'.e($m).'</div>';
    }
}
function header_html(string $title): void {
    $user = current_user();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>'.e($title).' | QuizCore</title><link rel="stylesheet" href="../assets/style.css"></head><body>';
    echo '<header class="topbar"><a class="brand" href="'.(($user['role'] ?? '')==='admin'?'../admin/index.php':'../student/index.php').'">◈ QuizCore</a>';
    echo '<div class="top-actions"><span>'.e($user['name'] ?? '').'</span><a class="btn btn-ghost" href="../logout.php">Sign out</a></div></header>';
    echo '<div class="layout"><aside class="sidebar"><div class="side-label">WORKSPACE</div>';
    if (($user['role'] ?? '') === 'admin') {
        echo '<a href="../admin/index.php">▦ Overview</a><a href="../admin/quizzes.php">▤ Manage quizzes</a><a href="../admin/users.php">♙ Users</a>';
    } else {
        echo '<a href="../student/index.php">▦ Dashboard</a><a href="../student/quizzes.php">▤ Available exams</a><a href="../student/results.php">◷ My results</a>';
    }
    echo '</aside><main class="main">';
    show_flash();
}
function footer_html(): void { echo '</main></div><script src="../assets/app.js"></script></body></html>'; }
