<?php
require_once __DIR__.'/includes/functions.php';
if (is_logged_in()) redirect(current_user()['role']==='admin'?'admin/index.php':'student/index.php');
redirect('login.php');
