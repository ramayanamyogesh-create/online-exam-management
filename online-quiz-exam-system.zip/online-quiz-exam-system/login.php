<?php
require_once __DIR__.'/includes/functions.php';
if (is_logged_in()) redirect(current_user()['role']==='admin'?'admin/index.php':'student/index.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $stmt=db()->prepare('SELECT id,name,email,password,role FROM users WHERE email=? LIMIT 1');
    $stmt->execute([trim($_POST['email']??'')]); $u=$stmt->fetch();
    if ($u && password_verify($_POST['password']??'', $u['password'])) {
        session_regenerate_id(true); unset($u['password']); $_SESSION['user']=$u;
        redirect($u['role']==='admin'?'admin/index.php':'student/index.php');
    } else $error='Invalid email or password.';
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sign in | QuizCore</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth-page"><section class="auth-card"><a class="brand" href="index.php">◈ QuizCore</a><h1>Welcome back</h1><p class="sub">Sign in to your examination workspace.</p><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="field"><label>Email address</label><input type="email" name="email" required autocomplete="username"></div><div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div><button class="btn" style="width:100%">Sign in</button></form><p class="help" style="margin-top:22px">New student? <a href="register.php" style="color:#a99fff">Create an account</a></p></section></body></html>
