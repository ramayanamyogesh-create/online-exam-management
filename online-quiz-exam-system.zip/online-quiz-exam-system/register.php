<?php
require_once __DIR__.'/includes/functions.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $name=trim($_POST['name']??'');$email=trim($_POST['email']??'');$pass=$_POST['password']??'';
 if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<8)$error='Enter a name, valid email, and password of at least 8 characters.';
 else{
  try{$s=db()->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'student')");$s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);flash('Account created. Please sign in.');redirect('login.php');}
  catch(PDOException $e){$error=$e->getCode()==='23000'?'That email is already registered.':'Could not create account.';}
 }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create account | QuizCore</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth-page"><section class="auth-card"><a class="brand" href="index.php">◈ QuizCore</a><h1>Create student account</h1><p class="sub">Register to take available examinations.</p><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="field"><label>Full name</label><input name="name" required maxlength="120"></div><div class="field"><label>Email address</label><input type="email" name="email" required></div><div class="field"><label>Password (minimum 8 characters)</label><input type="password" name="password" minlength="8" required></div><button class="btn" style="width:100%">Create account</button></form><p class="help" style="margin-top:20px"><a href="login.php" style="color:#a99fff">Back to sign in</a></p></section></body></html>
